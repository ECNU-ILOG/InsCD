from .interaction import GeneticInteractionFunc
from .parameter import Parameter
